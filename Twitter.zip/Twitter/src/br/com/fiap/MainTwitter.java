package br.com.fiap;

public class MainTwitter {
	public static void main(String[] args) {

		ApiTwitter twitter = new ApiTwitter();
		String resposta = "";

		// 1 - Postando mensagens
		System.out.println("Postando no meu Timeline");	
		resposta = twitter.TwittaMensagem("Boa noite para Todos!!!");
		System.out.println(resposta);
		System.out.println("");

		// 2 - Listando timeline
		System.out.println("Listando meu Timeline");	
		//twitter.TimelineTwitter();
		System.out.println("");

		// 3 - Localizando tweets por hashtag
		System.out.println("Listando #java");	
		//twitter.BuscaTweets("#java");
		System.out.println("");

		// 4 - Localizando tweets por hashtag Full
		System.out.println("Listando #java");	
		//twitter.BuscaReTweetsFullporDia("#java");
		System.out.println("");
	}
}
