package br.com.fiap;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import twitter4j.GeoLocation;
import twitter4j.Query;
import twitter4j.QueryResult;
import twitter4j.Status;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.auth.AccessToken;
import twitter4j.conf.Configuration;
import twitter4j.conf.ConfigurationBuilder;

public class ApiTwitter {

	/*# Twitter4J
	http://twitter4j.org/en/code-examples.html
	*/
	
	/*	SyL5exoyaoG7PDtt1YCg2cRFM
	 * 	DgIDJ1YUNcasGlSOYwvben17Wj0SktPaY1QPn7m3tS9WQ73WNl
	 *	728942590368854018-Eo8OyK4hcNUnJRyqILKdxCEThPGu2DD
	 * 	OpJ8L6uVvg06O42W8GoUZG10W73uFajb6rqOOHr1KIllL
	 */
	

	// Fun��o para Postar uma mensagem
	public String TwittaMensagem(String Mensagem) {
		String resposta = "";
		try {
			ConfigurationBuilder builder = new ConfigurationBuilder();
			builder.setOAuthConsumerKey("SyL5exoyaoG7PDtt1YCg2cRFM");
			builder.setOAuthConsumerSecret("DgIDJ1YUNcasGlSOYwvben17Wj0SktPaY1QPn7m3tS9WQ73WNl");
			Configuration configuration = builder.build();
			TwitterFactory factory = new TwitterFactory(configuration);
			Twitter twitter = factory.getInstance();
			AccessToken accessToken = loadAccessToken();
			twitter.setOAuthAccessToken(accessToken);
			Status status = twitter.updateStatus(Mensagem);
			resposta = "Tweet postado com sucesso! [" +	status.getText() + "].";
		} catch (Exception e) {
			//e.printStackTrace();
			resposta = e.getMessage();
			resposta = "Erro ao postar Tweet: " + e.getMessage();
		}
		return resposta;
	}

	// Token para postar Tweets
	private static AccessToken loadAccessToken(){
		String token = "728942590368854018-Eo8OyK4hcNUnJRyqILKdxCEThPGu2DD";
		String tokenSecret ="OpJ8L6uVvg06O42W8GoUZG10W73uFajb6rqOOHr1KIllL";
		return new AccessToken(token, tokenSecret);
	}

	// Getting Timeline - Twitter.get**** Timeline() returns a List of latest tweets from user's home timeline.
	public String TimelineTwitter() {
		String resposta = "";
		try {
			ConfigurationBuilder cb = new ConfigurationBuilder();
			cb.setDebugEnabled(true)
			.setOAuthConsumerKey("ConsumerKey###")
			.setOAuthConsumerSecret("ConsumerSecret###")
			.setOAuthAccessToken("AccessToken###")
			.setOAuthAccessTokenSecret("TokenSecret###");
			TwitterFactory tf = new TwitterFactory(cb.build());
			Twitter twitter = tf.getInstance();	

			// The factory instance is re-useable and thread safe.			
			//Twitter twitter = TwitterFactory.getSingleton();
			List<Status> statuses = twitter.getHomeTimeline();
			System.out.println("Showing home timeline.");
			int contador = 0;
			for (Status status : statuses) {
				contador = contador + 1;
				System.out.println("@ " + status.getUser().getName() + ":" + status.getCreatedAt() + " - " +  status.getText() + "Retweets: " + status.getRetweetCount());
			}
			System.out.println(contador + " registros encontrados.");
			resposta = "Timeline do Tweet.";

		} catch (Exception e) {
			e.printStackTrace();
			resposta = "Erro ao listar Timeline.";
		}
		return resposta;
	}

	// Search for Tweets - You can search for Tweets using Query class and Twitter.search(twitter4j.Query) method.
	public String BuscaTweets(String texto) {
		String resposta = "";
		try {
			ConfigurationBuilder cb = new ConfigurationBuilder();
			cb.setDebugEnabled(true)
			.setOAuthConsumerKey("ConsumeKey#####")
			.setOAuthConsumerSecret("ConsumerSecret###")
			.setOAuthAccessToken("AccessToken###")
			.setOAuthAccessTokenSecret("TokenSecret###");
			TwitterFactory tf = new TwitterFactory(cb.build());
			Twitter twitter = tf.getInstance();	

			int contador = 0;
			Query query = new Query(texto);
			query.setCount(100);
			QueryResult result = twitter.search(query);

			for (Status status : result.getTweets()) {
				contador = contador + 1;
				System.out.println(status.getId() + " @" + status.getUser().getScreenName() + ":"  + status.getCreatedAt() + " - " + status.getText()+ " Retweets: " + status.getRetweetCount() + " Favoritos: " + status.getFavoriteCount());
			}
			System.out.println(contador + " registros encontrados.");
			System.out.println();

			resposta = "Timeline do Tweet.";

		} catch (Exception e) {
			e.printStackTrace();
			resposta = "Erro ao listar Timeline.";
		}
		return resposta;
	}

	// 1. Quantidade por dia de tweets da �ltima semana.
	public String BuscaTweetsFullporDia(String texto) {
		String resposta = "";
		try {
			ConfigurationBuilder cb = new ConfigurationBuilder();
			cb.setDebugEnabled(true)
			.setOAuthConsumerKey("ConsumerKey###")
			.setOAuthConsumerSecret("ConsumerSecret###")
			.setOAuthAccessToken("AccessToken###")
			.setOAuthAccessTokenSecret("TokenSecret###");
			TwitterFactory tf = new TwitterFactory(cb.build());
			Twitter twitter = tf.getInstance();	

			/*
			 * 

				int contador = 0;
				Query query = new Query(texto);
				query.setCount(1000);
			    QueryResult result = twitter.search(query);

			    for (Status status : result.getTweets()) {
				 	contador = contador + 1;
					System.out.println(status.getId() + " @" + status.getUser().getScreenName() + ":"  + status.getCreatedAt() + " - " + status.getText()+ " Retweets: " + status.getRetweetCount() + " Favoritos: " + status.getFavoriteCount());
			    }
			    System.out.println(contador + " registros encontrados.");
				System.out.println();
			 */
			// Contar a quantidade de Mensagens 
			//Twitter twitter = new TwitterFactory(cb.build()).getInstance();
			Query query = new Query(texto);
			int numberOfTweets = 20000;
			long lastID = Long.MAX_VALUE;
			ArrayList<Status> tweets = new ArrayList<Status>();
			System.out.println("Contando tweets: " + tweets.size());

			
			while (tweets.size() < numberOfTweets) {
				if (numberOfTweets - tweets.size() > 100)
					query.setCount(100);
				else 
					query.setCount(numberOfTweets - tweets.size());
				try {
					QueryResult result = twitter.search(query);
					tweets.addAll(result.getTweets());
					System.out.println("Gathered: " + tweets.size() + " tweets");
					for (Status t: tweets) 
						if(t.getId() < lastID) lastID = t.getId();
				}
				catch (TwitterException te) {
					System.out.println("Couldn't connect: " + te);
				}; 
				query.setMaxId(lastID-1);
			}
			System.out.println("");

			System.out.println("Exibindo Tweets");
			for (int i = 0; i < tweets.size(); i++) {
				Status t = (Status) tweets.get(i);
				GeoLocation loc = t.getGeoLocation();
				String user = t.getUser().getScreenName();
				String msg = t.getText();
				Date time = t.getCreatedAt();
				int j = i + 1;
				if (loc!=null) {
					Double lat = t.getGeoLocation().getLatitude();
					Double lon = t.getGeoLocation().getLongitude();
					System.out.println(j + " USER: " + user + "Date: " + time +  " wrote: " + msg + " located at " + lat + ", " + lon);
				} 
				else 
					System.out.println(j + " USER: " + user + "Date: " + time +  " wrote: " + msg);
			}

			resposta = "Timeline do Tweet.";

		} catch (Exception e) {
			e.printStackTrace();
			resposta = "Erro ao listar Timeline.";
		}
		return resposta;
	}	

	// Usar estas fun��o abaixo para o trabalho	
	// 2. Quantidade por dia de retweets da �ltima semana.
	public String BuscaReTweetsFullporDia(String texto) {
		String resposta = "";
		try {
			ConfigurationBuilder cb = new ConfigurationBuilder();
			cb.setDebugEnabled(true)
			.setOAuthConsumerKey("SyL5exoyaoG7PDtt1YCg2cRFM")
			.setOAuthConsumerSecret("DgIDJ1YUNcasGlSOYwvben17Wj0SktPaY1QPn7m3tS9WQ73WNl")
			.setOAuthAccessToken("728942590368854018-Eo8OyK4hcNUnJRyqILKdxCEThPGu2DD")
			.setOAuthAccessTokenSecret("OpJ8L6uVvg06O42W8GoUZG10W73uFajb6rqOOHr1KIllL");
			TwitterFactory tf = new TwitterFactory(cb.build());
			Twitter twitter = tf.getInstance();	

			/*
			 *
			 *	int contador = 0;
				Query query = new Query(texto);
				query.setCount(1000);
			    QueryResult result = twitter.search(query);

			    for (Status status : result.getTweets()) {
				 	contador = contador + 1;
					System.out.println(status.getId() + " @" + status.getUser().getScreenName() + ":"  + status.getCreatedAt() + " - " + status.getText()+ " Retweets: " + status.getRetweetCount() + " Favoritos: " + status.getFavoriteCount());
			    }
			    System.out.println(contador + " registros encontrados.");
				System.out.println();
			 */

			//Twitter twitter = new TwitterFactory(cb.build()).getInstance();
			Query query = new Query(texto);
			int numberOfTweets = 20000;
			long lastID = Long.MAX_VALUE;
			ArrayList<Status> tweets = new ArrayList<Status>();
			System.out.println("Contando tweets: " + tweets.size());

			while (tweets.size() < numberOfTweets) {
				if (numberOfTweets - tweets.size() > 100)
					query.setCount(100);
				else 
					query.setCount(numberOfTweets - tweets.size());
				try {
					QueryResult result = twitter.search(query);
					tweets.addAll(result.getTweets());
					System.out.println("Gathered: " + tweets.size() + " tweets");
					for (Status t: tweets) 
						if(t.getId() < lastID) lastID = t.getId();
				}
				catch (TwitterException te) {
					System.out.println("Couldn't connect: " + te);
				}; 
				query.setMaxId(lastID-1);
			}
			System.out.println("");

			System.out.println("Exibindo Tweets");
			for (int i = 0; i < tweets.size(); i++) {
				Status t = (Status) tweets.get(i);
				GeoLocation loc = t.getGeoLocation();
				String user = t.getUser().getScreenName();
				String msg = t.getText();
				Date time = t.getCreatedAt();
				int j = i + 1;
				if (loc!=null) {
					Double lat = t.getGeoLocation().getLatitude();
					Double lon = t.getGeoLocation().getLongitude();
					System.out.println(j + " USER: " + user + "Date: " + time +  " wrote: " + msg + " located at " + lat + ", " + lon);
				} 
				else 
					System.out.println(j + " USER: " + user + "Date: " + time +  " wrote: " + msg);
			}

			resposta = "Timeline do Tweet.";

		} catch (Exception e) {
			e.printStackTrace();
			resposta = "Erro ao listar Timeline.";
		}
		return resposta;
	}	

	// Usar estas fun��o abaixo para o trabalho	
	//3. Quantidade por dia de favorita��es da �ltima semana.
	public String BuscaFavoritosFullnaSemana(String texto) {
		String resposta = "";
		try {
			ConfigurationBuilder cb = new ConfigurationBuilder();
			cb.setDebugEnabled(true)
			.setOAuthConsumerKey("ConsumerKey###")
			.setOAuthConsumerSecret("ConsumerSecret###")
			.setOAuthAccessToken("AccessToken###")
			.setOAuthAccessTokenSecret("TokenSecret###");
			TwitterFactory tf = new TwitterFactory(cb.build());
			Twitter twitter = tf.getInstance();	

			/*
			 * 

				int contador = 0;
				Query query = new Query(texto);
				query.setCount(1000);
			    QueryResult result = twitter.search(query);

			    for (Status status : result.getTweets()) {
				 	contador = contador + 1;
					System.out.println(status.getId() + " @" + status.getUser().getScreenName() + ":"  + status.getCreatedAt() + " - " + status.getText()+ " Retweets: " + status.getRetweetCount() + " Favoritos: " + status.getFavoriteCount());
			    }
			    System.out.println(contador + " registros encontrados.");
				System.out.println();
			 */

			//Twitter twitter = new TwitterFactory(cb.build()).getInstance();
			Query query = new Query(texto);
			int numberOfTweets = 20000;
			long lastID = Long.MAX_VALUE;
			ArrayList<Status> tweets = new ArrayList<Status>();
			System.out.println("Contando tweets: " + tweets.size());

			while (tweets.size() < numberOfTweets) {
				if (numberOfTweets - tweets.size() > 100)
					query.setCount(100);
				else 
					query.setCount(numberOfTweets - tweets.size());
				try {
					QueryResult result = twitter.search(query);
					tweets.addAll(result.getTweets());
					System.out.println("Gathered: " + tweets.size() + " tweets");
					for (Status t: tweets) 
						if(t.getId() < lastID) lastID = t.getId();
				}
				catch (TwitterException te) {
					System.out.println("Couldn't connect: " + te);
				}; 
				query.setMaxId(lastID-1);
			}
			System.out.println("");

			System.out.println("Exibindo Tweets");
			for (int i = 0; i < tweets.size(); i++) {
				Status t = (Status) tweets.get(i);
				GeoLocation loc = t.getGeoLocation();
				String user = t.getUser().getScreenName();
				String msg = t.getText();
				Date time = t.getCreatedAt();
				//t.getRetweetedStatus();
				//t.getFavoriteCount()
				int j = i + 1;
				if (loc!=null) {
					Double lat = t.getGeoLocation().getLatitude();
					Double lon = t.getGeoLocation().getLongitude();
					System.out.println(j + " USER: " + user + "Date: " + time +  " wrote: " + msg + " located at " + lat + ", " + lon);
				} 
				else 
					System.out.println(j + " USER: " + user + "Date: " + time +  " wrote: " + msg);
			}

			resposta = "Timeline do Tweet.";

		} catch (Exception e) {
			e.printStackTrace();
			resposta = "Erro ao listar Timeline.";
		}
		return resposta;
	}	

	// Usar estas fun��o abaixo para o trabalho	
	// 4. Ordenar os tweets pelo nome do autor, e exibir o primeiro nome e o �ltimo nome.
	public String BuscaTweetsFullPorNome(String texto) {
		String resposta = "";
		try {
			ConfigurationBuilder cb = new ConfigurationBuilder();
			cb.setDebugEnabled(true)
			.setOAuthConsumerKey("ConsumerKey###")
			.setOAuthConsumerSecret("ConsumerSecret###")
			.setOAuthAccessToken("AccessToken###")
			.setOAuthAccessTokenSecret("TokenSecret###");
			TwitterFactory tf = new TwitterFactory(cb.build());
			Twitter twitter = tf.getInstance();	

			/*
			 *
				int contador = 0;
				Query query = new Query(texto);
				query.setCount(1000);
			    QueryResult result = twitter.search(query);

			    for (Status status : result.getTweets()) {
				 	contador = contador + 1;
					System.out.println(status.getId() + " @" + status.getUser().getScreenName() + ":"  + status.getCreatedAt() + " - " + status.getText()+ " Retweets: " + status.getRetweetCount() + " Favoritos: " + status.getFavoriteCount());
			    }
			    System.out.println(contador + " registros encontrados.");
				System.out.println();
			 */

			//Twitter twitter = new TwitterFactory(cb.build()).getInstance();
			Query query = new Query(texto);
			int numberOfTweets = 20000;
			long lastID = Long.MAX_VALUE;
			ArrayList<Status> tweets = new ArrayList<Status>();
			System.out.println("Contando tweets: " + tweets.size());

			while (tweets.size() < numberOfTweets) {
				if (numberOfTweets - tweets.size() > 100)
					query.setCount(100);
				else 
					query.setCount(numberOfTweets - tweets.size());
				try {
					QueryResult result = twitter.search(query);
					tweets.addAll(result.getTweets());
					System.out.println("Gathered: " + tweets.size() + " tweets");
					for (Status t: tweets) 
						if(t.getId() < lastID) lastID = t.getId();
				}
				catch (TwitterException te) {
					System.out.println("Couldn't connect: " + te);
				}; 
				query.setMaxId(lastID-1);
			}
			System.out.println("");

			System.out.println("Exibindo Tweets");
			for (int i = 0; i < tweets.size(); i++) {
				Status t = (Status) tweets.get(i);
				GeoLocation loc = t.getGeoLocation();
				String user = t.getUser().getScreenName();
				String msg = t.getText();
				Date time = t.getCreatedAt();
				int j = i + 1;
				if (loc!=null) {
					Double lat = t.getGeoLocation().getLatitude();
					Double lon = t.getGeoLocation().getLongitude();
					System.out.println(j + " USER: " + user + "Date: " + time +  " wrote: " + msg + " located at " + lat + ", " + lon);
				} 
				else 
					System.out.println(j + " USER: " + user + "Date: " + time +  " wrote: " + msg);
			}

			resposta = "Timeline do Tweet.";

		} catch (Exception e) {
			e.printStackTrace();
			resposta = "Erro ao listar Timeline.";
		}
		return resposta;
	}	
	// Usar estas fun��o abaixo para o trabalho	
	
	// 5. Ordenar os tweets por data, e exibir a data mais recente e a menos recente.
	public String BuscaTweetsFullporData(String texto) {
		String resposta = "";
		try {
			ConfigurationBuilder cb = new ConfigurationBuilder();
			cb.setDebugEnabled(true)
			.setOAuthConsumerKey("ConsumerKey###")
			.setOAuthConsumerSecret("ConsumerSecret###")
			.setOAuthAccessToken("AccessToken###")
			.setOAuthAccessTokenSecret("TokenSecret###");
			TwitterFactory tf = new TwitterFactory(cb.build());
			Twitter twitter = tf.getInstance();	
			/*
			 * 	int contador = 0;
				Query query = new Query(texto);
				query.setCount(1000);
			    QueryResult result = twitter.search(query);

			    for (Status status : result.getTweets()) {
				 	contador = contador + 1;
					System.out.println(status.getId() + " @" + status.getUser().getScreenName() + ":"  + status.getCreatedAt() + " - " + status.getText()+ " Retweets: " + status.getRetweetCount() + " Favoritos: " + status.getFavoriteCount());
			    }
			    System.out.println(contador + " registros encontrados.");
				System.out.println();
			 */

			//Twitter twitter = new TwitterFactory(cb.build()).getInstance();
			Query query = new Query(texto);
			int numberOfTweets = 20000;
			long lastID = Long.MAX_VALUE;
			ArrayList<Status> tweets = new ArrayList<Status>();
			System.out.println("Contando tweets: " + tweets.size());

			while (tweets.size() < numberOfTweets) {
				if (numberOfTweets - tweets.size() > 100)
					query.setCount(100);
				else 
					query.setCount(numberOfTweets - tweets.size());
				try {
					QueryResult result = twitter.search(query);
					tweets.addAll(result.getTweets());
					System.out.println("Gathered: " + tweets.size() + " tweets");
					for (Status t: tweets) 
						if(t.getId() < lastID) lastID = t.getId();
				}
				catch (TwitterException te) {
					System.out.println("Couldn't connect: " + te);
				}; 
				query.setMaxId(lastID-1);
			}
			System.out.println("");

			System.out.println("Exibindo Tweets");
			for (int i = 0; i < tweets.size(); i++) {
				Status t = (Status) tweets.get(i);
				GeoLocation loc = t.getGeoLocation();
				String user = t.getUser().getScreenName();
				String msg = t.getText();
				Date time = t.getCreatedAt();
				int j = i + 1;
				if (loc!=null) {
					Double lat = t.getGeoLocation().getLatitude();
					Double lon = t.getGeoLocation().getLongitude();
					System.out.println(j + " USER: " + user + "Date: " + time +  " wrote: " + msg + " located at " + lat + ", " + lon);
				} 
				else 
					System.out.println(j + " USER: " + user + "Date: " + time +  " wrote: " + msg);
			}

			resposta = "Timeline do Tweet.";

		} catch (Exception e) {
			e.printStackTrace();
			resposta = "Erro ao listar Timeline.";
		}
		return resposta;
	}	

}