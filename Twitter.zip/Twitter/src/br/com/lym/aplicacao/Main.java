package br.com.lym.aplicacao;

import java.util.List;
import twitter4j.Status;
import twitter4j.Twitter;
import twitter4j.TwitterFactory;
import twitter4j.auth.AccessToken;

public class Main {

	public static void main(String[] args) {

		try {
			TwitterFactory factory = new TwitterFactory();
			AccessToken accessToken = loadAccessToken();
			Twitter twitter = factory.getSingleton();
			twitter.setOAuthConsumer("SyL5exoyaoG7PDtt1YCg2cRFM", "DgIDJ1YUNcasGlSOYwvben17Wj0SktPaY1QPn7m3tS9WQ73WNl");
			twitter.setOAuthAccessToken(accessToken);

			List<Status> statuses = twitter.getHomeTimeline();
			System.out.println("Home Timeline:");
			for (Status status : statuses) {
				System.out.println("Usu�rio: " +status.getUser().getName() + ":" + "Tweet:"+status.getText());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static AccessToken loadAccessToken(){
		String token = " 728942590368854018-Eo8OyK4hcNUnJRyqILKdxCEThPGu2DD";
		String tokenSecret = " OpJ8L6uVvg06O42W8GoUZG10W73uFajb6rqOOHr1KIllL";
		return new AccessToken(token, tokenSecret);
	}
}