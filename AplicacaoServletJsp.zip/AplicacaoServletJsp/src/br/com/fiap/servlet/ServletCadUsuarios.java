package br.com.fiap.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.fiap.dao.GenericDao;
import br.com.fiap.entity.Usuario;

@WebServlet(name = "Cadastro de Usu�rios", description = "Cadastro de Usu�rios", urlPatterns = { "/admin/cadusuario" })
public class ServletCadUsuarios extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ServletCadUsuarios() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("cadusuario.jsp").include(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try	{
			String nome = request.getParameter("nome");
			String senha = request.getParameter("senha");
			Integer nivel = Integer.parseInt(request.getParameter("nivel"));
			
			GenericDao<Usuario> dao = new GenericDao<Usuario>(Usuario.class);		
			
			Usuario usuario = new Usuario();
			usuario.setNome(nome);
			usuario.setSenha(senha);
			usuario.setNivel(nivel);
			
			dao.adicionar(usuario);
			
			request.setAttribute("msg", "Usu�rio " + usuario.getId() + " cadastrado com sucesso!");
		} catch(Exception e) {
			request.setAttribute("msg", "Erro: " + e.getMessage());
		} finally {
			request.getRequestDispatcher("cadusuario.jsp").forward(request, response);
		}
	}

}
