package br.com.petto.servlet;

import java.io.IOException;
import java.io.PrintWriter;

//import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(
		name = "Servlet Login", 
		description = "Servlet de Login de usu�rio", 
		urlPatterns = { "/valida" }, 
		initParams = { 
				@WebInitParam(name = "user", value = "admin"), 
				@WebInitParam(name = "pwd", value = "admin")
		})
public class ServletLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ServletLogin() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		//PrintWriter out = response.getWriter();
		//response.setContentType("text/html");
		//out.print("<h2>Bem vindo � aplica��o de cadastro de livros</b2><br/>");	
		
		request.getRequestDispatcher("login.jsp").include(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// doGet(request, response);
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		String user = request.getParameter("nome");
		String pass = request.getParameter("senha");
		
		//ServletConfig config = this.getServletConfig();
		//String userServer = config.getInitParameter("name");
		//String passServer = config.getInitParameter("pwd");
		String userServer = getServletConfig().getInitParameter("user");
		String passServer = getServletConfig().getInitParameter("pwd");
		
		if (user.equals(userServer) && pass.equals(passServer)) {
			out.print("<h2>Usu�rio validado com sucesso.</b2><br/>");		
			response.sendRedirect("admin/menu.jsp");
		} else {
			//out.print("<h2>Acesso negado!</b2><br/>");		
			//out.print("<a href=login.jsp>Voltar para Login</b2><br/>");
			//response.sendRedirect("login.jsp?message=LoginInvalido");
			request.setAttribute("msgValidacao","Usu�rio ou senha inv�lido!");
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}		
	}
}
