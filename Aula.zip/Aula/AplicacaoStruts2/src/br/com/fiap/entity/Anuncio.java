package br.com.fiap.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;


@Entity
@Table(name="anuncios")
public class Anuncio {
	
	@Id @GeneratedValue
	@Column(name="CODIGO")
	private Integer codigo;
	
	@Column(name="TITULO")
	private String titulo;
	
	@Column(name="DESCRICAO")
	private String descricao;
	
	@Column(name="DATA")
	private Date data;
	
	@Column(name="VALOR")
	private double valor;
	
	@Lob
	@Column(name="IMAGEM")
	private byte[] imagem;
		
	/*
	 * 	TINYBLOB => 255 Bytes
		BLOB => 64 Kilobytes
		MEDIUMBLOB => 16 Megabytes
		LONGBLOB => 4 Gigabits 
	 */
	
	public Integer getCodigo() {
		return codigo;
	}
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	public Date getData() {
		return data;
	}
	public void setData(Date data) {
		this.data = data;
	}
	
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	
	public byte[] getImagem() {
		return imagem;
	}

	public void setImagem(byte[] imagem) {
		this.imagem = imagem;
	}
}

