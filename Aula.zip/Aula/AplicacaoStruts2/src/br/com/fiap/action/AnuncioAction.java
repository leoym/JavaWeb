package br.com.fiap.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import br.com.fiap.dao.GenericDao;
import br.com.fiap.entity.Anuncio;
import com.opensymphony.xwork2.ActionSupport;

@Results({
	@Result(name="ok", location="/sucesso.jsp"),
	@Result(name="erro", location="/erro.jsp"),
	@Result(name="input", location="/cadAnuncios.jsp"),
	@Result(name="lista", location="/listaAnuncios.jsp")
})

public class AnuncioAction extends ActionSupport{
	private static final long serialVersionUID = 1L;

	private File figura;
	private Anuncio anuncio;
	private List<Anuncio> listaAnuncios;

	public AnuncioAction(){
		anuncio = new Anuncio();
		listaAnuncios = new ArrayList<>();
	}
	public File getFigura() { 
		return figura;
	}
	public void setFigura(File figura) {
		this.figura = figura;
	}
	public Anuncio getAnuncio() {
		return anuncio;
	}
	public void setAnuncio(Anuncio anuncio) {
		this.anuncio = anuncio;
	}

	public List<Anuncio> getListaAnuncios() {
		return listaAnuncios;
	}
	public void setListaAnuncio(List<Anuncio> listaAnuncios) {
		this.listaAnuncios = listaAnuncios;
	}
	@Action(value="/cadastro1")
	public String incluir(){
		try {
			InputStream inputStream = new FileInputStream(figura);
			byte[] imagem = new byte[(int)figura.length()];
			inputStream.read(imagem, 0, (int)figura.length());
			anuncio.setImagem(imagem);
			GenericDao<Anuncio> dao = new GenericDao<Anuncio>(Anuncio.class);
			dao.adicionar(anuncio);
			inputStream.close();
			return "ok";
		} catch (Exception e) {
			return "erro";
		}
	}

	@Action(value="/consulta1")
	public String listar(){
		GenericDao<Anuncio> dao = new GenericDao<Anuncio>(Anuncio.class);
		listaAnuncios = dao.listar();
		return "lista";
	}
}